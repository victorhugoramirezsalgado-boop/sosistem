# S.O.S. VHRS — PWA de pruebas 0.1

Prototipo inicial para publicar en `sosistem.com` y probar desde Safari en iPhone 16.

## Qué incluye

- Panel de prueba adaptable a móvil.
- Inicio y detención manual de cámara con permiso explícito.
- Análisis local experimental de cambios entre fotogramas reducidos (64 × 48).
- Pruebas de voz, vibración y escenarios simulados.
- Historial en memoria de sesión y exportación CSV manual.
- Service worker para recursos estáticos y funcionamiento básico sin conexión después de la primera carga.

## Límites importantes

- **No es un sistema de seguridad certificado ni debe utilizarse para emergencias reales.**
- El análisis de imagen detecta cambios visuales; no detecta de forma fiable personas, caídas, humo, armas, sismos ni condiciones médicas.
- No guarda ni envía fotogramas, audio, ubicación o datos personales. Los registros se mantienen en memoria y solo se exportan cuando el usuario pulsa el botón.
- No hay backend, cuentas, transmisión a `sosistem.com`, llamadas a emergencias ni alertas a terceros configuradas.
- Las PWA en iOS tienen limitaciones de cámara, vibración, segundo plano y ejecución con pantalla bloqueada. Para supervisión fiable y funciones de sistema, se requiere una app iOS nativa y pruebas específicas.
- No se solicita acceso al micrófono. La función de voz solo reproduce texto mediante la síntesis disponible en el navegador.
- La exportación CSV contiene eventos y horas; revisa el archivo antes de compartirlo.

## Publicar en hosting/cPanel

1. Descarga y descomprime `sos-vhrs-pwa.zip` en tu ordenador.
2. Entra al panel cPanel de `sosistem.com`.
3. Abre **Administrador de archivos** y localiza la raíz del dominio. Normalmente es `public_html/`, pero confirma la ruta asignada al dominio.
4. Si el dominio usa una carpeta propia, entra en esa carpeta. Sube el contenido de la carpeta del proyecto, no el ZIP solamente:
   - `index.html`
   - `manifest.webmanifest`
   - `sw.js`
   - `icons/icon.svg`
5. Comprueba que el dominio tiene un certificado SSL válido y que abre con `https://sosistem.com/`.
6. Abre `https://sosistem.com/` y verifica que aparece “Centro de pruebas”.
7. En iPhone 16, abre la dirección en **Safari**, toca **Compartir** y selecciona **Añadir a pantalla de inicio**. Abre el icono instalado.
8. Prueba primero voz y escenarios simulados. Solo después, con consentimiento, toca “Iniciar cámara” y concede permiso. Detén la cámara al terminar.
9. Comprueba exportación CSV y confirma que no hay cargas de archivos ni llamadas de red con datos de eventos.

## MIME types

Si el servidor no reconoce los tipos, configura:
- `.webmanifest` → `application/manifest+json`
- `.js` → `text/javascript`
- `.svg` → `image/svg+xml`

No es necesario modificar `.htaccess` si el servidor ya sirve correctamente estos tipos.

## Validación después de publicar

- [ ] HTTPS válido y sin advertencias.
- [ ] Página carga en Safari.
- [ ] Icono se puede añadir a la pantalla de inicio.
- [ ] Cámara pide permiso y se detiene correctamente.
- [ ] No se guarda ni transmite imagen o audio.
- [ ] Voz y simulaciones funcionan según las capacidades de iOS.
- [ ] CSV se descarga y contiene solo los eventos esperados.
- [ ] No se realizan llamadas reales ni se notifica a terceros.

## Próxima fase

Antes de integrar registros remotos, define autenticación, retención, cifrado, permisos, auditoría y un backend seguro. Para detección de caídas o supervisión continua, diseña una aplicación nativa iOS y valida los algoritmos con escenarios controlados y métricas de falsos positivos/negativos.
