S.O.S. VHRS — interfaz experimental de sensores

Contenido:
- index.html: interfaz móvil para pruebas de permiso de movimiento, cámara local, registros de sesión y exportación CSV.

Cómo probar:
1. Publicar index.html en un servidor HTTPS (por ejemplo en una carpeta /pruebas/ del sitio).
2. Abrir la URL en Safari en el iPhone.
3. Pulsar explícitamente los botones de permisos para probar movimiento/cámara.
4. Para añadir a inicio: Safari > Compartir > Añadir a pantalla de inicio.

Límites importantes:
- No existe conexión de backend ni API a SOSistem.com.
- El control “Enviar datos” no transmite nada y se desactiva a propósito.
- La ubicación y el micrófono no se solicitan.
- Los registros son temporales durante la sesión, salvo que el usuario los exporte a CSV.
- No detecta caídas de forma fiable ni llama a emergencias. No usar para seguridad real.
